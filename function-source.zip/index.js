// Require necessary modules
require("dotenv").config();
const express = require('express');
const mongoose = require('mongoose');
const Book = require('./book');

// Create an express app
const app = express();
app.use(express.json());

// Connect to MongoDB using the MONGO_URI environment variable
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    console.log('Connected to MongoDB');
}).catch((err) => {
    console.error('Error connecting to MongoDB:', err);
    process.exit(1);
});

// Define routes
app.post('/book', (req, res) => {
    const newBook = new Book(req.body);
    newBook.save().then(() => {
        res.send('New Book added successfully!');
    }).catch((err) => {
        res.status(500).send('Internal Server Error!');
    });
});

app.get('/book', (req, res) => {
    Book.find().then((books) => {
        if (books.length !== 0) {
            res.json(books);
        } else {
            res.status(404).send('Books not found');
        }
    }).catch((err) => {
        res.status(500).send('Internal Server Error!');
    });
});

app.get('/book/:id', (req, res) => {
    Book.findById(req.params.id).then((book) => {
        if (book) {
            res.json(book);
        } else {
            res.status(404).send('Book not found');
        }
    }).catch((err) => {
        res.status(500).send('Internal Server Error!');
    });
});

app.delete('/book/:id', (req, res) => {
    Book.findByIdAndRemove(req.params.id).then((book) => {
        if (book) {
            res.json('Book deleted successfully!');
        } else {
            res.status(404).send('Book not found');
        }
    }).catch((err) => {
        res.status(500).send('Internal Server Error!');
    });
});

// Export the Express app
exports.booksTest = app;
